#include <GL/glut.h>
#include <cmath>


// Car and cloud positions
float carPos1 = -1.0f;   // Start position of the car (left side)
float carPos2 = 0.0f;
float cloudPos1 = 1.0f;  // Start position of the cloud (right side)
float cloudPos2 = 0.5f;
float ballPosX = -0.5f;  // Starting X position of the ball
float ballPosY = -0.8f;  // Starting Y position of the ball
float ballSpeedX = 0.005f; // Ball speed in X direction
float ballSpeedY = 0.001f; // Ball speed in Y direction

// Function to draw a rectangle
void drawRect(float x1, float y1, float x2, float y2, float r, float g, float b) {
    glColor3f(r, g, b);
    glBegin(GL_POLYGON);
    glVertex2f(x1, y1);
    glVertex2f(x2, y1);
    glVertex2f(x2, y2);
    glVertex2f(x1, y2);
    glEnd();
}

// Function to draw an ellipse
void drawEllipse(float cx, float cy, float rx, float ry, int num_segments, float r, float g, float b) {
    glColor3f(r, g, b);
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(cx, cy); // Center of the ellipse
    for (int i = 0; i <= num_segments; ++i) {
        float theta = 2.0f * 3.1415926f * float(i) / float(num_segments);
        float x = rx * cos(theta);
        float y = ry * sin(theta);
        glVertex2f(x + cx, y + cy);
    }
    glEnd();
}

// Function to draw a more realistic tree
void drawRealisticTree(float x, float y) {
    // Tree trunk
    drawRect(x - 0.02f, y, x + 0.02f, y + 0.15f, 0.54f, 0.27f, 0.07f); // Brown trunk

    // Tree leaves using ellipses
    drawEllipse(x, y + 0.2f, 0.1f, 0.15f, 100, 0.0f, 0.5f, 0.0f);  // Dark green leaves (bottom)
    drawEllipse(x, y + 0.3f, 0.08f, 0.12f, 100, 0.0f, 0.7f, 0.0f);  // Lighter green leaves (middle)
    drawEllipse(x, y + 0.37f, 0.06f, 0.09f, 100, 0.0f, 0.9f, 0.0f);  // Light green leaves (top)
}

// Function to draw a more realistic cloud
void drawRealisticCloud(float x, float y) {
    // Use multiple ellipses to form a fluffy cloud
    drawEllipse(x, y, 0.2f, 0.1f, 100, 1.0f, 1.0f, 1.0f);  // Main body of the cloud
    drawEllipse(x + 0.1f, y + 0.05f, 0.15f, 0.08f, 100, 1.0f, 1.0f, 1.0f);  // Top right
    drawEllipse(x - 0.1f, y + 0.03f, 0.17f, 0.09f, 100, 1.0f, 1.0f, 1.0f);  // Top left
    drawEllipse(x + 0.05f, y - 0.04f, 0.13f, 0.07f, 100, 1.0f, 1.0f, 1.0f);  // Bottom right
    drawEllipse(x - 0.05f, y - 0.05f, 0.14f, 0.06f, 100, 1.0f, 1.0f, 1.0f);  // Bottom left
}

// Function to draw a building
void drawBuilding(float x, float y, float width, float height, int floors) {
    float windowWidth = width / 6;
    float windowHeight = height / (floors * 2);
    float floorHeight = height / floors;

    // Draw the building
    drawRect(x, y, x + width, y + height, 0.7f, 0.7f, 0.7f);  // Light gray building

    // Draw windows for each floor
    for (int i = 0; i < floors; ++i) {
        float floorY = y + i * floorHeight;
        for (int j = 0; j < 2; ++j) {
            float wx = x + width * (j + 1) / 3;
            float wy = floorY + floorHeight / 2;
            drawRect(wx - windowWidth / 2, wy - windowHeight / 2, wx + windowWidth / 2, wy + windowHeight / 2, 1.0f, 1.0f, 1.0f); // White windows
        }
    }
}

// Function to draw a more realistic car
void drawRealisticCar(float x, float y) {
    // Car body
    drawRect(x, y, x + 0.4f, y + 0.1f, 0.8f, 0.0f, 0.0f);  // Red car body (slightly longer)

    // Car roof
    drawRect(x + 0.1f, y + 0.1f, x + 0.3f, y + 0.2f, 0.9f, 0.9f, 0.9f);  // White car roof

    // Car windows
    drawRect(x + 0.12f, y + 0.12f, x + 0.18f, y + 0.18f, 0.2f, 0.2f, 0.8f);  // Left window
    drawRect(x + 0.22f, y + 0.12f, x + 0.28f, y + 0.18f, 0.2f, 0.2f, 0.8f);  // Right window

    // Car wheels
    drawEllipse(x + 0.1f, y - 0.02f, 0.05f, 0.05f, 100, 0.0f, 0.0f, 0.0f);  // Left wheel
    drawEllipse(x + 0.3f, y - 0.02f, 0.05f, 0.05f, 100, 0.0f, 0.0f, 0.0f);  // Right wheel

    // Headlights
    drawRect(x + 0.38f, y + 0.02f, x + 0.4f, y + 0.06f, 1.0f, 1.0f, 0.0f);  // Yellow headlights

    // Rear lights
    drawRect(x, y + 0.02f, x + 0.02f, y + 0.06f, 1.0f, 0.0f, 0.0f);  // Red rear lights
}

// Function to draw a more realistic human figure
void drawRealisticHuman(float x, float y) {
    // Head
    drawEllipse(x, y + 0.08f, 0.03f, 0.04f, 100, 1.0f, 0.8f, 0.6f); // Light skin tone

    // Body (shirt)
    drawRect(x - 0.025f, y - 0.08f, x + 0.025f, y + 0.02f, 0.0f, 0.0f, 1.0f); // Blue shirt

    // Arms (using ellipses for curved appearance)
    drawEllipse(x - 0.045f, y - 0.02f, 0.02f, 0.07f, 100, 1.0f, 0.8f, 0.6f); // Left arm
    drawEllipse(x + 0.045f, y - 0.02f, 0.02f, 0.07f, 100, 1.0f, 0.8f, 0.6f); // Right arm

    // Legs (pants)
    drawRect(x - 0.02f, y - 0.25f, x, y - 0.08f, 0.3f, 0.3f, 0.3f); // Left leg (dark gray pants)
    drawRect(x, y - 0.25f, x + 0.02f, y - 0.08f, 0.3f, 0.3f, 0.3f); // Right leg (dark gray pants)

    // Shoes (black)
    drawRect(x - 0.025f, y - 0.25f, x - 0.005f, y - 0.27f, 0.0f, 0.0f, 0.0f); // Left shoe
    drawRect(x + 0.005f, y - 0.25f, x + 0.025f, y - 0.27f, 0.0f, 0.0f, 0.0f); // Right shoe

    // Hair
    drawEllipse(x, y + 0.1f, 0.03f, 0.02f, 100, 0.1f, 0.1f, 0.1f); // Black hair
}

// Function to draw the football (white ball)
void drawFootball(float x, float y) {
    drawEllipse(x, y, 0.03f, 0.03f, 100, 1.0f, 1.0f, 1.0f);  // White ball
}

// Timer function to animate the car and cloud movement
void update(int value) {
    carPos1 += 0.01f;// Move the car to the right
    carPos2 += 0.01f;
    cloudPos1 -= 0.0005f; // Move the cloud to the left
      cloudPos2 -= 0.0005f; // Move the cloud to the left
           ballPosX += ballSpeedX;
    ballPosY += ballSpeedY;

    // Reset car and cloud positions for continuous movement
    if (carPos1 > 1.2f ) {
        carPos1 = -1.2f; // Wrap around the screen

    }

    if(carPos2 > 1.2f){
       carPos2 = -1.2f;
    }

    if (cloudPos1 < -1.2f) {
        cloudPos1 = 1.2f; // Wrap around the screen
    }

     if (cloudPos2 < -1.2f) {
        cloudPos2 = 1.2f; // Wrap around the screen
    }



    // Ball bouncing between two humans
    if (ballPosX > 0.5f || ballPosX < -0.5f) {
        ballSpeedX = -ballSpeedX;
    }
    if (ballPosY > -0.7f || ballPosY < -0.9f) {
        ballSpeedY = -ballSpeedY;
    }

    glutPostRedisplay();                // Redraw the scene
    glutTimerFunc(16, update, 0);       // Call update again after 16ms (about 60 FPS)
}

// Display function
void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    // Draw the sky
    drawRect(-1.0f, 0.0f, 1.0f, 1.0f, 0.529f, 0.808f, 0.98f);  // Light blue sky

    // Draw the field
    drawRect(-1.0f, -1.0f, 1.0f, -0.2f, 0.0f, 0.8f, 0.0f);  // Green field

    // Draw the road
    drawRect(-1.0f, -0.4f, 1.0f, -0.1f, 0.5f, 0.5f, 0.5f);  // Light gray road

    // Draw the sun
    drawEllipse(0.7f, 0.7f, 0.1f, 0.1f, 100, 1.0f, 1.0f, 0.0f);  // Yellow sun

    // Draw realistic clouds
    drawRealisticCloud(cloudPos1, 0.8f);  // Left cloud
    drawRealisticCloud(cloudPos2, 0.6f);   // Right cloud

    // Draw the buildings
    drawBuilding(-0.8f, -0.1f, 0.2f, 0.4f, 4);  // Building 1 (4 floors)
    drawBuilding(-0.3f, -0.1f, 0.2f, 0.3f, 3);  // Building 2 (3 floors)
    drawBuilding(0.2f, -0.1f, 0.2f, 0.5f, 5);   // Building 3 (5 floors)




    // Draw trees in the green area
    drawRealisticTree(-0.6f, -0.1f);  // Tree 1
    drawRealisticTree(-0.3f, -0.1f);  // Tree 2
    drawRealisticTree(0.0f, -0.1f);   // Tree 3
    drawRealisticTree(0.7f, -0.1f);   // Tree 4


     // Draw realistic cars on the road
    drawRealisticCar(carPos1, -0.2f);  // First car
    drawRealisticCar(carPos2, -0.3f);   // Second car

      drawRealisticTree(-0.8f, -0.7f);  // Tree 2
    drawRealisticTree(0.6f, -0.6f);  // Tree 2

     // Draw humans in the green area
    drawRealisticHuman(-0.5f, -0.7f);  // Human 1
    drawRealisticHuman(0.1f, -0.3f);   // Human 2
    drawRealisticHuman(0.6f, -0.7f);   // Human 3

       drawFootball(ballPosX, ballPosY);

    glFlush();
}

// Initialize function to set up the window
void init() {
    glClearColor(0.529f, 0.808f, 0.922f, 1.0f); // Sky blue background color
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-1.0, 1.0, -1.0, 1.0);  // Set coordinate system
}

// Main function
int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(800, 600);
    glutCreateWindow("Realistic Cityscape with Moving Car and Cloud");
    init();
    glutDisplayFunc(display);
    glutTimerFunc(16, update, 0);  // Start the timer for animation
    glutMainLoop();
    return 0;
}
