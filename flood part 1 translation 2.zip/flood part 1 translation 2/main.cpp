#include <GL/glut.h>
#include <math.h>
#include <iostream>
#include <cstdlib>  // Include this for rand() and srand()
#include <ctime>    // Include this to seed the random number generator

using namespace std;

float boatX = 0.0f;  // Boat's horizontal position
bool moveBoat = false;  // Flag to start moving the boat

float sunX = -1.0f;  // Initial position of the sun
float sunY = 0.7f;
float sunDirection = 0.0f;  // 0.0 for stationary, 1.0 for moving right

float cloudX = -0.7f;  // Initial horizontal position of the cloud
float cloudX2 = -0.3f;
float cloudX3 = 0.7f;
float cloudSpeed = 0.0f;  // Speed of cloud movement

float birdX = -1.0f;  // Initial horizontal position of the birds
float birdSpeed = 0.0002f;  // Speed of bird movement

// Additional global variable for water movement
float riverFlowOffset = 0.0f;
float riverSpeed = 0.00009f;  // Speed of the river flow

// Function prototypes
void drawBird(float x, float y);

void drawRect(float x1, float y1, float x2, float y2, float r, float g, float b) {
    glColor3f(r, g, b);
    glBegin(GL_POLYGON);
    glVertex2f(x1, y1);
    glVertex2f(x2, y1);
    glVertex2f(x2, y2);
    glVertex2f(x1, y2);
    glEnd();
}

void drawTriangle(float x1, float y1, float x2, float y2, float x3, float y3, float r, float g, float b) {
    glColor3f(r, g, b);
    glBegin(GL_TRIANGLES);
    glVertex2f(x1, y1);
    glVertex2f(x2, y2);
    glVertex2f(x3, y3);
    glEnd();
}

void drawCircle(float cx, float cy, float radius, int num_segments, float r, float g, float b) {
    glColor3f(r, g, b);
    glBegin(GL_TRIANGLE_FAN);
    for (int i = 0; i < num_segments; i++) {
        float theta = 2.0f * 3.1415926f * float(i) / float(num_segments);
        float x = radius * cos(theta);
        float y = radius * sin(theta);
        glVertex2f(x + cx, y + cy);
    }
    glEnd();
}

// New function to draw a bird using triangles
void drawBird(float x, float y) {
    glColor3f(0.0f, 0.0f, 0.0f);  // Black color for the birds
    glBegin(GL_LINES);
    glVertex2f(x - 0.03f, y);
    glVertex2f(x, y + 0.03f);
    glVertex2f(x, y + 0.03f);
    glVertex2f(x + 0.03f, y);
    glEnd();
}

void drawEllipse(float cx, float cy, float rx, float ry, int num_segments, float r, float g, float b) {
    glColor3f(r, g, b);
    glBegin(GL_TRIANGLE_FAN);
    for (int i = 0; i < num_segments; i++) {
        float theta = 2.0f * 3.1415926f * float(i) / float(num_segments);
        float x = rx * cosf(theta);
        float y = ry * sinf(theta);
        glVertex2f(x + cx, y + cy);
    }
    glEnd();
}

void drawTree(float x, float y) {
    // Trunk
    drawRect(x - 0.025f, y, x + 0.025f, y + 0.2f, 0.545f, 0.271f, 0.075f);  // Brown trunk

    // Leaves (using ellipses and circles to create a more realistic look)
    drawEllipse(x, y + 0.25f, 0.15f, 0.1f, 100, 0.0f, 0.6f, 0.0f);  // Bottom layer of leaves
    drawEllipse(x + 0.05f, y + 0.35f, 0.1f, 0.08f, 100, 0.0f, 0.8f, 0.0f);  // Middle layer of leaves
    drawEllipse(x - 0.05f, y + 0.35f, 0.1f, 0.08f, 100, 0.0f, 0.7f, 0.0f);  // Middle layer of leaves
    drawCircle(x, y + 0.4f, 0.1f, 100, 0.0f, 0.9f, 0.0f);  // Top layer of leaves
}


  // Initial position of the boat

void keyboard(unsigned char key, int x, int y) {
    switch (key) {
        case 'r':
            // Start moving the sun
            sunDirection = 1.0f;
            moveBoat = true;
            cloudSpeed =0.000015f;

            break;
        case 27: // ESC key to exit
            exit(0);
            break;
    }
    glutPostRedisplay();
}


void idle() {
    if (sunDirection == 1.0f) {
        sunX += 0.00001f; // Move the sun to the right
        sunY += 0.000001f; // Move the sun upwards

        if (sunX > 1.0f) {  // Stop at the right side
            sunX = -1.3f;
            sunY = 0.9f;
            sunDirection = -2.0f;
        }
    }

    if (moveBoat) {
        boatX += 0.0001f;  // Change this value to adjust the speed of the boat
        if (boatX > 1.5f) boatX = -1.2f;  // Reset position if it goes off-screen
    }

    // Move the cloud
    cloudX += cloudSpeed;
    if (cloudX > 1.0f) cloudX = -1.0f;  // Reset cloud position if it goes off-screen

    cloudX2 += cloudSpeed;
    if (cloudX2 > 1.0f) cloudX2 = -1.0f;  // Reset cloud position if it goes off-screen

     cloudX3 += cloudSpeed;
    if (cloudX3 > 1.0f) cloudX3 = -1.0f;  // Reset cloud position if it goes off-screen


     // Move the birds
    birdX += birdSpeed;
    if (birdX > 1.2f) birdX = -1.2f;  // Reset bird position if it goes off-screen

    // Move the river flow continuously from left to right
    riverFlowOffset += riverSpeed;
    if (riverFlowOffset > 0.1f) {
        riverFlowOffset -= 0.1f;  // Reset wave position smoothly to avoid gaps
    }
    glutPostRedisplay();
}


void drawCloud(float x, float y) {
    drawCircle(x, y, 0.1f, 100, 1.0f, 1.0f, 1.0f);  // Main part of the cloud
    drawCircle(x + 0.1f, y - 0.02f, 0.08f, 100, 1.0f, 1.0f, 1.0f);  // Left part of the cloud
    drawCircle(x + 0.1f, y + 0.1f, 0.08f, 100, 1.0f, 1.0f, 1.0f);  // Right part of the cloud
}



void drawBoat() {
    // Hull of the boat (trapezoid)
    glColor3f(0.6f, 0.3f, 0.0f);  // Brown
    glBegin(GL_POLYGON);
    glVertex2f(boatX - 0.15f, -0.3f);
    glVertex2f(boatX + 0.15f, -0.3f);
    glVertex2f(boatX + 0.1f, -0.4f);
    glVertex2f(boatX - 0.1f, -0.4f);
    glEnd();

    // Upper part of the boat (rectangle)
    drawRect(boatX - 0.1f, -0.2f, boatX + 0.1f, -0.3f, 1.0f, 0.5f, 0.0f);  // Yellow

    // Mast
    drawRect(boatX - 0.001f, -0.2f, boatX + 0.02f, 0.1f, 0.5f, 0.35f, 0.05f);  // Dark brown

    // Sail
    drawTriangle(boatX + 0.02f, 0.1f, boatX + 0.02f, -0.05f, boatX + 0.2f, 0.005f, 0.9f, 0.9f, 0.9f);  // White sail
}



void drawMountain(float x, float y, float width, float height, float r, float g, float b) {
    glColor3f(r, g, b);
    glBegin(GL_TRIANGLES);
    glVertex2f(x - width / 2, y);  // Left vertex
    glVertex2f(x + width / 2, y);  // Right vertex
    glVertex2f(x, y + height);     // Top vertex
    glEnd();
}

void drawMountains() {
    // Draw layered mountains behind the land area
    drawMountain(-0.8f, 0.1f, 0.6f, 0.4f, 0.6f, 0.3f, 0.2f);  // Mountain 1 (left)
    drawMountain(-0.4f, 0.1f, 0.7f, 0.5f, 0.5f, 0.35f, 0.25f);  // Mountain 2 (left center)
    drawMountain(0.0f, 0.1f, 0.6f, 0.4f, 0.6f, 0.3f, 0.2f);    // Mountain 3 (center)
    drawMountain(0.4f, 0.1f, 0.7f, 0.5f, 0.5f, 0.35f, 0.25f);   // Mountain 4 (right center)
    drawMountain(0.8f, 0.1f, 0.6f, 0.4f, 0.6f, 0.3f, 0.2f);    // Mountain 5 (right)
}

void drawLandArea() {
    // Land area (a simple flat green field)
    drawRect(-1.0f, -0.1f, 1.0f, 0.1f, 0.0f, 0.8f, 0.0f);  // Flat green area
}


void drawHouse(float x, float y) {
    // House body
    drawRect(x, y, x + 0.2f, y + 0.2f, 1.0f, 0.8f, 0.0f);  // Yellow body

    // Roof
    drawTriangle(x - 0.05f, y + 0.2f, x + 0.1f, y + 0.35f, x + 0.25f, y + 0.2f, 0.8f, 0.0f, 0.0f);  // Red roof

    // Door
    drawRect(x + 0.08f, y, x + 0.12f, y + 0.1f, 0.5f, 0.3f, 0.0f);  // Brown door

    // Windows
    drawRect(x + 0.02f, y + 0.12f, x + 0.06f, y + 0.16f, 0.0f, 0.6f, 1.0f);  // Left window
    drawRect(x + 0.14f, y + 0.12f, x + 0.18f, y + 0.16f, 0.0f, 0.6f, 1.0f);  // Right window
}

void drawRiver() {
    // River base with gradient
    glBegin(GL_POLYGON);
    glColor3f(0.0f, 0.3f, 0.8f);  // Darker blue for the deeper parts
    glVertex2f(-1.0f, -0.5f);
    glVertex2f(1.0f, -0.5f);
    glColor3f(0.0f, 0.5f, 1.0f);  // Lighter blue for the shallower parts
    glVertex2f(1.0f, -0.1f);
    glVertex2f(-1.0f, -0.1f);
    glEnd();

    // Moving water effect
    glColor3f(1.0f, 1.0f, 1.0f);  // White for waves
    glBegin(GL_LINES);
    for (float y = -0.5f; y < -0.1f; y += 0.05f) {
        for (float x = -1.0f; x < 1.0f; x += 0.1f) {
            // Shift the waves to the right to simulate movement
            float waveOffset = (x + riverFlowOffset);
            glVertex2f(waveOffset, y);
            glVertex2f(waveOffset + 0.05f, y + 0.03f);
        }
    }
    glEnd();
}
void drawRain() {
    glColor3f(1.0f, 1.0f, 1.0f);  // Light grey for rain
    glBegin(GL_LINES);
    for (int i = 0; i < 100; i++) {
        float x = (float)rand() / RAND_MAX * 2.0f - 1.0f;  // Random x between -1 and 1
        float y = (float)rand() / RAND_MAX * 2.0f - 1.0f;  // Random y between -1 and 1
        glVertex2f(x, y);
        glVertex2f(x, y - 0.1f);  // Short rain drops
    }
    glEnd();
}

void drawFisherman(float x, float y) {
    // Body Parameters
    float headRadius = 0.05f;
    float bodyWidth = 0.04f;
    float bodyHeight = 0.1f;
    float legWidth = 0.01f;
    float legHeight = 0.07f;
    float armWidth = 0.02f;
    float armHeight = 0.06f;

    // Draw Head
    glColor3f(1.0f, 0.8f, 0.6f);  // Skin color
    drawCircle(x, y + bodyHeight + headRadius, headRadius, 100, 1.0f, 0.8f, 0.6f);  // Head

    // Draw Facial Features
    // Eyes
    glColor3f(0.0f, 0.0f, 0.0f);  // Black color for eyes
    float eyeOffsetX = 0.015f;
    float eyeOffsetY = 0.01f;
    drawCircle(x - eyeOffsetX, y + bodyHeight + headRadius + eyeOffsetY, 0.005f, 20, 0.0f, 0.0f, 0.0f);  // Left eye
    drawCircle(x + eyeOffsetX, y + bodyHeight + headRadius + eyeOffsetY, 0.005f, 20, 0.0f, 0.0f, 0.0f);  // Right eye

    // Mouth
    glBegin(GL_LINE_STRIP);
    glVertex2f(x - 0.015f, y + bodyHeight + headRadius - 0.01f);
    glVertex2f(x, y + bodyHeight + headRadius - 0.02f);
    glVertex2f(x + 0.015f, y + bodyHeight + headRadius - 0.01f);
    glEnd();

    // Draw Hat
    glColor3f(0.3f, 0.2f, 0.1f);  // Dark brown for hat
    glBegin(GL_TRIANGLES);
    glVertex2f(x - headRadius, y + bodyHeight + 2 * headRadius);
    glVertex2f(x + headRadius, y + bodyHeight + 2 * headRadius);
    glVertex2f(x, y + bodyHeight + 2.5f * headRadius);
    glEnd();

    // Draw Body (Clothing)
    glColor3f(0.0f, 0.0f, 0.8f);  // Blue shirt
    drawRect(x - bodyWidth, y, x + bodyWidth, y + bodyHeight, 0.0f, 0.0f, 0.8f);  // Torso

    // Draw Arms
    glColor3f(1.0f, 0.8f, 0.6f);  // Skin color for arms
    // Left Arm
    drawRect(x - bodyWidth - armWidth, y + 0.05f, x - bodyWidth, y + 0.05f + armHeight, 1.0f, 0.8f, 0.6f);
    // Right Arm holding fishing rod
    glColor3f(1.0f, 0.8f, 0.6f);  // Skin color
    drawRect(x + bodyWidth, y + 0.05f, x + bodyWidth + armWidth, y + 0.05f + armHeight, 1.0f, 0.8f, 0.6f);

    // Fishing Rod (Enhanced Position)
    glColor3f(0.4f, 0.2f, 0.0f);  // Brown color
    glBegin(GL_LINES);
    glVertex2f(x + bodyWidth + armWidth, y + 0.05f + armHeight);  // Start of rod
    glVertex2f(x + bodyWidth + armWidth + 0.1f, y + 0.2f);       // End of rod
    glEnd();

    // Fishing Line
    glColor3f(0.7f, 0.7f, 0.7f);  // Light gray color
    glBegin(GL_LINES);
    glVertex2f(x + bodyWidth + armWidth + 0.1f, y + 0.2f);  // Start of line
    glVertex2f(x + bodyWidth + armWidth + 0.15f, y + 0.15f); // End of line
    glEnd();

    // Fish on the Hook
    drawCircle(x + bodyWidth + armWidth + 0.15f, y + 0.15f, 0.02f, 100, 1.0f, 0.5f, 0.0f);  // Fish

    // Draw Legs
    glColor3f(0.0f, 0.0f, 0.0f);  // Black pants
    // Left Leg
    drawRect(x - legWidth - 0.005f, y - legHeight, x - legWidth + 0.005f, y, 0.0f, 0.0f, 0.0f);
    // Right Leg
    drawRect(x + legWidth - 0.005f, y - legHeight, x + legWidth + 0.005f, y, 0.0f, 0.0f, 0.0f);

    // Draw Shoes
    glColor3f(0.545f, 0.271f, 0.075f);  // Brown shoes
    // Left Shoe
    drawRect(x - legWidth - 0.01f, y - legHeight, x - legWidth + 0.01f, y - legHeight + 0.005f, 0.545f, 0.271f, 0.075f);
    // Right Shoe
    drawRect(x + legWidth - 0.01f, y - legHeight, x + legWidth + 0.01f, y - legHeight + 0.005f, 0.545f, 0.271f, 0.075f);

    // Optional: Add details like belt
    glColor3f(0.545f, 0.271f, 0.075f);  // Brown belt
    drawRect(x - bodyWidth, y + 0.05f, x + bodyWidth, y + 0.06f, 0.545f, 0.271f, 0.075f);  // Belt

    // Optional: Add a pocket or other clothing details
    glColor3f(0.8f, 0.8f, 0.8f);  // Light gray for pocket
    drawRect(x - 0.015f, y + 0.02f, x - 0.005f, y + 0.04f, 0.8f, 0.8f, 0.8f);  // Pocket

       // Bucket beside the fisherman
    glColor3f(0.5f, 0.5f, 0.5f);  // Gray color for the bucket
    drawEllipse(x + 0.12f, y - 0.1f, 0.05f, 0.07f, 100, 0.5f, 0.5f, 0.5f);  // Main part of the bucket
    drawRect(x + 0.1f, y - 0.17f, x + 0.14f, y - 0.1f, 0.3f, 0.3f, 0.3f);  // Bucket handle

}




void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    // Sky
    drawRect(-1.0f, 0.0f, 1.0f, 1.0f, 0.529f, 0.808f, 0.98f);  // Light blue sky

    // Draw mountains behind the land area
    drawMountains();

    // River
    drawRect(-1.0f, -0.5f, 1.0f, 0.0f, 0.0f, 0.3f, 0.8f);  // River background
    drawRiver();  // Draw the more realistic river

    // Sun
    drawCircle(sunX, sunY, 0.1f, 100, 1.0f, 1.0f, 0.0f);  // Yellow sun

    // Clouds
    drawCloud(cloudX, 0.8f);  // Draw moving cloud
    drawCloud(cloudX2, 0.6f);
    drawCloud(cloudX3, 0.7f);

    // Land area (replacing the hill)
    drawLandArea();

    // Houses and other elements as before
    drawHouse(-0.3f, 0.0f);  // First house on the left
    drawHouse(0.4f, 0.1f);   // Second house on the right

    // Trees beside the houses (realistic version)
    drawTree(-0.55f, 0.0f);  // Tree 1 (beside first house)
    drawTree(0.25f, 0.0f);   // Tree 2 (beside second house)
    drawTree(0.7f, 0.06f);   // Tree 3 (extra tree)

    // Realistic Boat (centered in the river)
    drawBoat();

       // Houses and Trees below the river (lowered)
    drawHouse(-0.8f, -0.7f);  // First house on the left
    drawHouse(0.4f, -0.7f);   // Second house on the right

     drawTree(-0.55f, -0.8f);  // Tree 1 (beside first house)
    drawTree(0.7f, -0.85f);   // Tree 2 (beside second house)

        // Draw birds flying in the sky
    drawBird(birdX, 0.85f);  // First bird
    drawBird(birdX + 0.2f, 0.9f);  // Second bird flying behind
    drawBird(birdX + 0.4f, 0.87f);  // Third bird flying higher

     // Draw the fisherman beside the river
    drawFisherman(-0.2f ,-0.6f);  // Adjust the position as needed


    glFlush();
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(1366, 768);
    glutCreateWindow("Scenery with Realistic Houses");
    glClearColor(0.529f, 0.808f, 0.0f,0.8f);  // Light blue sky
    gluOrtho2D(-1.0, 1.0, -1.0, 1.0);
    srand(time(0));
    glutDisplayFunc(display);
    glutKeyboardFunc(keyboard);
    glutIdleFunc(idle);  // Register the idle function
    glutMainLoop();
    return 0;
}
