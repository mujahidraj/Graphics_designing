#include <GL/glut.h>
#include <cmath>

// Function to draw a rectangle
void drawRect(float x1, float y1, float x2, float y2, float r, float g, float b) {
    glColor3f(r, g, b);
    glBegin(GL_POLYGON);
    glVertex2f(x1, y1);
    glVertex2f(x2, y1);
    glVertex2f(x2, y2);
    glVertex2f(x1, y2);
    glEnd();
}

// Function to draw a circle
void drawCircle(float cx, float cy, float radius, int num_segments, float r, float g, float b) {
    glColor3f(r, g, b);
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(cx, cy); // Center of circle
    for (int i = 0; i <= num_segments; ++i) {
        float theta = 2.0f * 3.1415926f * float(i) / float(num_segments);
        float x = radius * cos(theta);
        float y = radius * sin(theta);
        glVertex2f(x + cx, y + cy);
    }
    glEnd();
}

// Function to draw a building
void drawBuilding(float x, float y, float width, float height, int floors) {
    float windowWidth = width / 6;
    float windowHeight = height / (floors * 2);
    float floorHeight = height / floors;

    // Draw the building
    drawRect(x, y, x + width, y + height, 0.7f, 0.7f, 0.7f);  // Light gray building

    // Draw windows for each floor
    for (int i = 0; i < floors; ++i) {
        float floorY = y + i * floorHeight;
        for (int j = 0; j < 2; ++j) {
            float wx = x + width * (j + 1) / 3;
            float wy = floorY + floorHeight / 2;
            drawRect(wx - windowWidth / 2, wy - windowHeight / 2, wx + windowWidth / 2, wy + windowHeight / 2, 1.0f, 1.0f, 1.0f); // White windows
        }
    }
}

// Function to draw a car
void drawCar(float x, float y) {
    // Car body
    drawRect(x, y, x + 0.3f, y + 0.1f, 0.8f, 0.1f, 0.1f); // Red car body

    // Car roof
    drawRect(x + 0.1f, y + 0.1f, x + 0.2f, y + 0.2f, 0.8f, 0.1f, 0.1f); // Red car roof

    // Car wheels
    drawCircle(x + 0.1f, y - 0.02f, 0.05f, 100, 0.0f, 0.0f, 0.0f); // Left wheel
    drawCircle(x + 0.25f, y - 0.02f, 0.05f, 100, 0.0f, 0.0f, 0.0f); // Right wheel
}

// Display function
void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    // Draw the sky
    drawRect(-1.0f, 0.0f, 1.0f, 1.0f, 0.529f, 0.808f, 0.98f);  // Light blue sky

    // Draw the road
    drawRect(-1.0f, -0.2f, 1.0f, -0.1f, 0.5f, 0.5f, 0.5f);  // Light gray road

    // Draw the field
    drawRect(-1.0f, -1.0f, 1.0f, -0.2f, 0.0f, 0.8f, 0.0f);  // Green field

    // Draw the sun
    drawCircle(0.7f, 0.7f, 0.1f, 100, 1.0f, 1.0f, 0.0f);  // Yellow sun

    // Draw clouds
    drawCircle(-0.8f, 0.8f, 0.1f, 100, 1.0f, 1.0f, 1.0f);  // Left cloud
    drawCircle(-0.7f, 0.85f, 0.08f, 100, 1.0f, 1.0f, 1.0f); // Left cloud
    drawCircle(-0.6f, 0.8f, 0.1f, 100, 1.0f, 1.0f, 1.0f);  // Additional cloud
    drawCircle(-0.5f, 0.85f, 0.08f, 100, 1.0f, 1.0f, 1.0f); // Additional cloud
    drawCircle(0.6f, 0.8f, 0.1f, 100, 1.0f, 1.0f, 1.0f);   // Right cloud
    drawCircle(0.7f, 0.85f, 0.08f, 100, 1.0f, 1.0f, 1.0f);  // Right cloud
    drawCircle(0.8f, 0.75f, 0.1f, 100, 1.0f, 1.0f, 1.0f);   // Additional cloud
    drawCircle(0.9f, 0.8f, 0.08f, 100, 1.0f, 1.0f, 1.0f);   // Additional cloud

    // Draw the buildings
    drawBuilding(-0.8f, -0.1f, 0.2f, 0.4f, 4);  // Building 1 (4 floors)
    drawBuilding(-0.3f, -0.1f, 0.2f, 0.3f, 3);  // Building 2 (3 floors)
    drawBuilding(0.2f, -0.1f, 0.2f, 0.5f, 5);   // Building 3 (5 floors)

    // Draw cars on the road
    drawCar(-0.6f, -0.2f);  // First car
    drawCar(0.1f, -0.2f);   // Second car

    glFlush();
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(800, 600);
    glutCreateWindow("Cityscape with Buildings and Cars");
    glClearColor(0.529f, 0.808f, 0.98f, 1.0f); // Set the clear color to blue sky
    gluOrtho2D(-1.0, 1.0, -1.0, 1.0);
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}
