#include <windows.h>
#include <GL/gl.h>
#include <GL/glut.h>


void display() {
    //glClearColor(0.0f, 0.0f, 0.0f, 1.0f); // Set background color to black
	glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);

//South Africa

    //blue
    glColor3f(0.0, 0.0, .75);
    glBegin(GL_POLYGON);
    glVertex2f(1.0,0.0);
    glVertex2f(1.0,0.33);
    glVertex2f(.5,.33);
    glVertex2f(.5,0);
    glEnd();


    glColor3f(0.0, 0.0, .75);
    glBegin(GL_POLYGON);
    glVertex2f(.5,0.0);
    glVertex2f(.5,.33);
    glVertex2f(.2,0);
    glEnd();


    //green
    glColor3f(0.0, 0.6, 0.0);
    glBegin(GL_POLYGON);
    glVertex2f(1.0,0.38);
    glVertex2f(1.0,0.63);
    glVertex2f(0.50,0.63);
    glVertex2f(0.50,0.38);
    glEnd();


    glColor3f(0.0, 0.6, 0.0);
    glBegin(GL_POLYGON);
    glVertex2f(0.50,0.63);
    glVertex2f(.15,1.0);
    glVertex2f(0.0,1.0);
    glVertex2f(0.0, 0.92);
    glVertex2f(.38,.50);
    glVertex2f(0.0,.08);
    glVertex2f(0.0, 0.0);
    glVertex2f(0.15,0.0);
    glVertex2f(0.50,0.38);


    glEnd();


    //Yellow
    glColor3f(2.55,1.82 , 0.18);
    glBegin(GL_POLYGON);
    glVertex2f(.38,.50);
    glVertex2f(0.0, 0.92);
    glVertex2f(0.0,0.85);
    glVertex2f(0.32,.50);
    glVertex2f(0.0, .15);
    glVertex2f(0.0,.08);
    glEnd();


    //red
    glColor3f(2.22, .15, .15);
    glBegin(GL_POLYGON);
    glVertex2f(1.0,0.67);
    glVertex2f(1.0,1.0);
    glVertex2f(.50,1.0);
    glVertex2f(.50,0.67);
    glEnd();


    glColor3f(2.22, 0.15, 0.15);
    glBegin(GL_POLYGON);
    glVertex2f(1.0,1.0);
    glVertex2f(.20,1.0);
    glVertex2f(.50,0.67);
    glEnd();


    //Black Triangle

    glColor3f(0.0, 0.0, 0.0);
    glBegin(GL_POLYGON);
    glVertex2f(0.0, .15);
    glVertex2f(0.32,.50);
    glVertex2f(0.0,0.85);
    glEnd();


    glFlush();
}

void init() {
    glClearColor(1.0, 1.0, 1.0, 1.0);
    gluOrtho2D(-1.0, 1.0, -1.0, 1.0);
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(880, 640);
    glutInitWindowPosition(50, 50);
    glutCreateWindow("Flag of South Africa");
    init();
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}

