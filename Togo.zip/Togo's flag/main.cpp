#include <GL/glut.h>

void displayTogoFlag() {
    glClear(GL_COLOR_BUFFER_BIT);

    // Green stripes
    glColor3f(0.0, 0.6, 0.2); // Green color
    glBegin(GL_QUADS);
        glVertex2f(-1.0, 1.0);
        glVertex2f(1.0, 1.0);
        glVertex2f(1.0, 0.6);
        glVertex2f(-1.0, 0.6);
    glEnd();

    glBegin(GL_QUADS);
        glVertex2f(-1.0, 0.2);
        glVertex2f(1.0, 0.2);
        glVertex2f(1.0, -0.2);
        glVertex2f(-1.0, -0.2);
    glEnd();

    glBegin(GL_QUADS);
        glVertex2f(-1.0, -0.6);
        glVertex2f(1.0, -0.6);
        glVertex2f(1.0, -1.0);
        glVertex2f(-1.0, -1.0);
    glEnd();

    // Yellow stripes
    glColor3f(1.0, 0.8, 0.0); // Yellow color
    glBegin(GL_QUADS);
        glVertex2f(-1.0, 0.6);
        glVertex2f(1.0, 0.6);
        glVertex2f(1.0, 0.2);
        glVertex2f(-1.0, 0.2);
    glEnd();

    glBegin(GL_QUADS);
        glVertex2f(-1.0, -0.2);
        glVertex2f(1.0, -0.2);
        glVertex2f(1.0, -0.6);
        glVertex2f(-1.0, -0.6);
    glEnd();

    // Red square
    glColor3f(0.8, 0.0, 0.0); // Red color
    glBegin(GL_QUADS);
        glVertex2f(-1.0, 1.0);
        glVertex2f(-0.4, 1.0);
        glVertex2f(-0.4, 0.4);
        glVertex2f(-1.0, 0.4);
    glEnd();

    // White star
    glColor3f(1.0, 1.0, 1.0); // White color
    glBegin(GL_TRIANGLES);
        glVertex2f(-0.7, 0.8);
        glVertex2f(-0.75, 0.65);
        glVertex2f(-0.65, 0.65);

        glVertex2f(-0.7, 0.7);
        glVertex2f(-0.75, 0.85);
        glVertex2f(-0.65, 0.85);

        glVertex2f(-0.75, 0.75);
        glVertex2f(-0.7, 0.9);
        glVertex2f(-0.65, 0.75);
    glEnd();

    glFlush();
}

void init() {
    glClearColor(1.0, 1.0, 1.0, 1.0); // Set background color to white
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-1.0, 1.0, -1.0, 1.0);
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(800, 400);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("Flag of Togo");
    init();
    glutDisplayFunc(displayTogoFlag);
    glutMainLoop();
    return 0;
}
