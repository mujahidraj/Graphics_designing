#include <GL/glut.h>
#include <math.h>
#include <iostream>
#include <cstdlib>  // Include this for rand() and srand()
#include <ctime>    // Include this to seed the random number generator

using namespace std;

float boatX = 0.0f;  // Boat's horizontal position
bool moveBoat = false;  // Flag to start moving the boat

float cloudX = -0.7f;  // Initial horizontal position of the cloud
float cloudX2 = -0.3f;
float cloudX3 = 0.7f;
float cloudSpeed = 0.0f;  // Speed of cloud movement

float birdX = -1.0f;  // Initial horizontal position of the birds
float birdSpeed = 0.0002f;  // Speed of bird movement

// Additional global variable for water movement
float riverFlowOffset = 0.0f;
float riverSpeed = 0.00009f;  // Speed of the river flow

// Function prototypes
void drawBird(float x, float y);

float fishX = -0.9f;  // Initial position of the fish
float fishY = -0.35f;  // Fish swimming near the bottom of the river
bool fishCaught = false;  // To check if the fish is caught
int fishCount = 0;  // Number of fish caught
float fishingRodAngle = 0.0f;  // Initial angle for the fishing rod
float fishSize = 0.05f;  // Size of the fish
float catchDistance = 0.1f;  // Distance within which the fish gets caught

bool isDay = true;  // Variable to track whether it's day or night
bool isRain =false;

float sunX = -1.0f; // Starting position of the sun
float moonX = -1.0f; // Starting position of the moon
float speed = 0.0001f; // Speed of movement

bool thunderActive = false; // To track if thunder is active
int thunderDuration = 0; // Duration for thunder effect

bool iscloud = false;




void drawRect(float x1, float y1, float x2, float y2, float r, float g, float b) {
    glColor3f(r, g, b);
    glBegin(GL_POLYGON);
    glVertex2f(x1, y1);
    glVertex2f(x2, y1);
    glVertex2f(x2, y2);
    glVertex2f(x1, y2);
    glEnd();
}

void drawTriangle(float x1, float y1, float x2, float y2, float x3, float y3, float r, float g, float b) {
    glColor3f(r, g, b);
    glBegin(GL_TRIANGLES);
    glVertex2f(x1, y1);
    glVertex2f(x2, y2);
    glVertex2f(x3, y3);
    glEnd();
}

void drawCircle(float cx, float cy, float radius, int num_segments, float r, float g, float b) {
    glColor3f(r, g, b);
    glBegin(GL_TRIANGLE_FAN);
    for (int i = 0; i < num_segments; i++) {
        float theta = 2.0f * 3.1415926f * float(i) / float(num_segments);
        float x = radius * cos(theta);
        float y = radius * sin(theta);
        glVertex2f(x + cx, y + cy);
    }
    glEnd();
}

// New function to draw a bird using triangles
void drawBird(float x, float y) {
    glColor3f(0.0f, 0.0f, 0.0f);  // Black color for the birds
    glBegin(GL_LINES);
    glVertex2f(x - 0.03f, y);
    glVertex2f(x, y + 0.03f);
    glVertex2f(x, y + 0.03f);
    glVertex2f(x + 0.03f, y);
    glEnd();
}

void drawEllipse(float cx, float cy, float rx, float ry, int num_segments, float r, float g, float b) {
    glColor3f(r, g, b);
    glBegin(GL_TRIANGLE_FAN);
    for (int i = 0; i < num_segments; i++) {
        float theta = 2.0f * 3.1415926f * float(i) / float(num_segments);
        float x = rx * cosf(theta);
        float y = ry * sinf(theta);
        glVertex2f(x + cx, y + cy);
    }
    glEnd();
}

void drawTree(float x, float y) {
    // Trunk
    drawRect(x - 0.025f, y, x + 0.025f, y + 0.2f, 0.545f, 0.271f, 0.075f);  // Brown trunk

    // Leaves (using ellipses and circles to create a more realistic look)
    drawEllipse(x, y + 0.25f, 0.15f, 0.1f, 100, 0.0f, 0.6f, 0.0f);  // Bottom layer of leaves
    drawEllipse(x + 0.05f, y + 0.35f, 0.1f, 0.08f, 100, 0.0f, 0.8f, 0.0f);  // Middle layer of leaves
    drawEllipse(x - 0.05f, y + 0.35f, 0.1f, 0.08f, 100, 0.0f, 0.7f, 0.0f);  // Middle layer of leaves
    drawCircle(x, y + 0.4f, 0.1f, 100, 0.0f, 0.9f, 0.0f);  // Top layer of leaves
}

void drawnightTree(float x, float y) {
    // Trunk
    drawRect(x - 0.025f, y, x + 0.025f, y + 0.2f, 0.545f, 0.271f, 0.075f);  // Brown trunk

    // Leaves (using ellipses and circles to create a more realistic look)
    drawEllipse(x, y + 0.25f, 0.15f, 0.1f, 100, 0.0f, 0.3f, 0.0f);  // Bottom layer of leaves
    drawEllipse(x + 0.05f, y + 0.35f, 0.1f, 0.08f, 100, 0.0f, 0.5f, 0.0f);  // Middle layer of leaves
    drawEllipse(x - 0.05f, y + 0.35f, 0.1f, 0.08f, 100, 0.0f, 0.4f, 0.0f);  // Middle layer of leaves
    drawCircle(x, y + 0.4f, 0.1f, 100, 0.0f, 0.6f, 0.0f);  // Top layer of leaves
}



void keyboard(unsigned char key, int x, int y) {
    switch (key) {
        case 'm':
            moveBoat = true;  // Start moving the boat

            break;
        case 's':
            moveBoat = false;  // Stop moving the boat
            break;

        case 'f':
            fishingRodAngle += 45.0f;  // Rotate the fishing rod by 45 degrees
            break;
        case 'n':
            isDay = !isDay;  // Toggle between day and night
            break;
        case 'r':
            isRain =true;
            break;
        case 't':
            isRain=false;
            break;
        case 'y':
            iscloud=true;
            break;
        case 'u':
            iscloud=false;
            break;

        case 27: // ESC key to exit
            exit(0);
            break;
    }
    glutPostRedisplay();
}

void drawSky() {
    if (isDay) {
        drawRect(-1.0f, 0.1f, 1.0f, 1.0f, 0.5f, 0.7f, 1.0f);  // Day sky color
    } else {
        drawRect(-1.0f, 0.1f, 1.0f, 1.0f, 0.0f, 0.0f, 0.2f);  // Night sky color
    }
}

void drawcloudSky() {
    if (isDay) {
        drawRect(-1.0f, 0.1f, 1.0f, 1.0f, 0.5f, 0.5f, 0.5f);  // Day sky color
    } else {
        drawRect(-1.0f, 0.1f, 1.0f, 1.0f, 0.5f, 0.5f, 0.5f);  // Night sky color
    }
}


void drawSun() {
    glColor3f(1.0f, 1.0f, 0.0f); // Yellow color for the sun
    drawCircle(sunX, 0.8f, 0.1f, 100, 1.0f, 1.0f, 0.0f); // Adjust drawCircle parameters as needed
}

void drawMoon() {
    glColor3f(1.0f, 1.0f, 1.0f); // White color for the moon
    drawCircle(moonX, 0.8f, 0.1f, 100, 0.8f, 0.8f, 0.0f); // Adjust drawCircle parameters as needed
}


void idle() {

       sunX += speed; // Move the sun to the right
    moonX += speed; // Move the moon to the right

    // Wrap around when off-screen
    if (sunX > 1.0f) {
        sunX = -1.0f; // Reset sun position
    }
    if (moonX > 1.0f) {
        moonX = -1.0f; // Reset moon position
    }

    cloudSpeed = 0.00015f;  // Ensure cloud speed is set


    // Move the clouds automatically
    cloudX += cloudSpeed;
    if (cloudX > 1.0f) cloudX = -1.0f;  // Reset cloud position if it goes off-screen

    cloudX2 += cloudSpeed;
    if (cloudX2 > 1.0f) cloudX2 = -1.0f;  // Reset cloud position if it goes off-screen

    cloudX3 += cloudSpeed;
    if (cloudX3 > 1.0f) cloudX3 = -1.0f;  // Reset cloud position if it goes off-screen

    // Move the boat only if the flag is set
    if (moveBoat) {
        boatX += 0.0001f;  // Change this value to adjust the speed of the boat
        if (boatX > 1.5f) boatX = -1.2f;  // Reset position if it goes off-screen
    }

    // Move the birds
    birdX += birdSpeed;
    if (birdX > 1.2f) birdX = -1.2f;  // Reset bird position if it goes off-screen

    // Move the river flow
    riverFlowOffset += riverSpeed;
    if (riverFlowOffset > 0.1f) {
        riverFlowOffset -= 0.1f;  // Reset wave position smoothly
    }

    // Fish movement logic (same as before)
    if (!fishCaught) {
        fishX += 0.0001f;  // Fish swims from left to right
        if (fishX > 1.0f) fishX = -0.9f;  // Reset fish position if off-screen
        if (abs(fishX - boatX) < 0.05f && !fishCaught) {
            fishCaught = true;  // Fish is caught
            fishCount++;  // Increment fish count
        }
    } else {
        fishX = boatX + 0.2f;  // Move fish to the right of the boat
        fishY = -0.1f;  // Move fish near the bucket
        static int delay = 0;
        if (++delay > 2000) {
            fishCaught = false;
            fishX = -0.9f;  // Reset fish position
            fishY = -0.35f;  // Reset fish Y position
            delay = 0;
        }
    }

    glutPostRedisplay();
}


void drawCloud(float x, float y) {
    drawCircle(x, y, 0.1f, 100, 1.0f, 1.0f, 1.0f);  // Main part of the cloud
    drawCircle(x + 0.1f, y - 0.02f, 0.08f, 100, 1.0f, 1.0f, 1.0f);  // Left part of the cloud
    drawCircle(x + 0.1f, y + 0.1f, 0.08f, 100, 1.0f, 1.0f, 1.0f);  // Right part of the cloud
}



void drawBoat() {
    // Hull of the boat (trapezoid)
    glColor3f(0.6f, 0.3f, 0.0f);  // Brown
    glBegin(GL_POLYGON);
    glVertex2f(boatX - 0.15f, -0.3f);
    glVertex2f(boatX + 0.15f, -0.3f);
    glVertex2f(boatX + 0.1f, -0.4f);
    glVertex2f(boatX - 0.1f, -0.4f);
    glEnd();

    // Upper part of the boat (rectangle)
    drawRect(boatX - 0.1f, -0.2f, boatX + 0.1f, -0.3f, 1.0f, 0.5f, 0.0f);  // Yellow

    // Mast
    drawRect(boatX - 0.001f, -0.2f, boatX + 0.02f, 0.1f, 0.5f, 0.35f, 0.05f);  // Dark brown

    // Sail
    drawTriangle(boatX + 0.02f, 0.1f, boatX + 0.02f, -0.05f, boatX + 0.2f, 0.005f, 0.9f, 0.9f, 0.9f);  // White sail
}



void drawMountain(float x, float y, float width, float height, float r, float g, float b) {
    glColor3f(r, g, b);
    glBegin(GL_TRIANGLES);
    glVertex2f(x - width / 2, y);  // Left vertex
    glVertex2f(x + width / 2, y);  // Right vertex
    glVertex2f(x, y + height);     // Top vertex
    glEnd();
}

void drawMountains() {
    // Draw layered mountains behind the land area
    drawMountain(-0.8f, 0.1f, 0.6f, 0.4f, 0.6f, 0.3f, 0.2f);  // Mountain 1 (left)
    drawMountain(-0.4f, 0.1f, 0.7f, 0.5f, 0.5f, 0.35f, 0.25f);  // Mountain 2 (left center)
    drawMountain(0.0f, 0.1f, 0.6f, 0.4f, 0.6f, 0.3f, 0.2f);    // Mountain 3 (center)
    drawMountain(0.4f, 0.1f, 0.7f, 0.5f, 0.5f, 0.35f, 0.25f);   // Mountain 4 (right center)
    drawMountain(0.8f, 0.1f, 0.6f, 0.4f, 0.6f, 0.3f, 0.2f);    // Mountain 5 (right)
}

void drawLandArea() {
    // Land area (a simple flat green field)
    drawRect(-1.0f, -0.1f, 1.0f, 0.1f, 0.0f, 0.6f, 0.0f);  // Flat green area
}

void drawnightLandArea() {
    // Land area (a simple flat green field)
    drawRect(-1.0f, -0.1f, 1.0f, 0.1f, 0.0f, 0.3f, 0.0f);  // Flat green area
}



void drawHouse(float x, float y) {
    // House body
    drawRect(x, y, x + 0.2f, y + 0.2f, 0.8f, 0.6f, 0.0f);  // Yellow body

    // Roof
    drawTriangle(x - 0.05f, y + 0.2f, x + 0.1f, y + 0.35f, x + 0.25f, y + 0.2f, 0.3f, 0.0f, 0.0f);  // Red roof

    // Door
    drawRect(x + 0.08f, y, x + 0.12f, y + 0.1f, 0.5f, 0.3f, 0.0f);  // Brown door

    // Windows
    drawRect(x + 0.02f, y + 0.12f, x + 0.06f, y + 0.16f, 0.0f, 0.6f, 1.0f);  // Left window
    drawRect(x + 0.14f, y + 0.12f, x + 0.18f, y + 0.16f, 0.0f, 0.6f, 1.0f);  // Right window
}

void drawRiver() {
    // River base with gradient
    glBegin(GL_POLYGON);
    glColor3f(0.0f, 0.3f, 0.8f);  // Darker blue for the deeper parts
    glVertex2f(-1.0f, -0.5f);
    glVertex2f(1.0f, -0.5f);
    glColor3f(0.0f, 0.5f, 1.0f);  // Lighter blue for the shallower parts
    glVertex2f(1.0f, -0.1f);
    glVertex2f(-1.0f, -0.1f);
    glEnd();

    // Moving water effect
    glColor3f(0.0f, 0.0f, 1.0f);  // White for waves
    glBegin(GL_LINES);
    for (float y = -0.5f; y < -0.1f; y += 0.05f) {
        for (float x = -1.0f; x < 1.0f; x += 0.1f) {
            // Shift the waves to the right to simulate movement
            float waveOffset = (x + riverFlowOffset);
            glVertex2f(waveOffset, y);
            glVertex2f(waveOffset + 0.02f, y + 0.03f);
        }
    }
    glEnd();
}
void drawRain() {
    glColor3f(1.0f, 1.0f, 1.0f);  // Light grey for rain
    glBegin(GL_LINES);
    for (int i = 0; i < 100; i++) {
        float x = (float)rand() / RAND_MAX * 2.0f - 1.0f;  // Random x between -1 and 1
        float y = (float)rand() / RAND_MAX * 2.0f - 1.0f;  // Random y between -1 and 1
        glVertex2f(x, y);
        glVertex2f(x, y - 0.1f);  // Short rain drops
    }
    glEnd();
}

void drawThunder() {
    if (isRain) {
        // Randomly trigger thunder
        if (!thunderActive && (rand() % 100 < 1)) { // 1% chance per frame to start thunder
            thunderActive = true;
            thunderDuration = rand() % 10 + 5; // Thunder duration between 5 and 15 frames
        }

        // Thunder effect in the sky
        if (thunderActive) {
            // Draw a white rectangle in the upper sky region
            glColor3f(1.0f, 1.0f, 1.0f); // Set color to white
            glBegin(GL_QUADS);
                glVertex2f(-1.0f, 1.0f);  // Top left corner of the sky
                glVertex2f(1.0f, 1.0f);   // Top right corner of the sky
                glVertex2f(1.0f, 0.0f);   // Bottom right corner of the sky (upper half)
                glVertex2f(-1.0f, 0.0f);  // Bottom left corner of the sky (upper half)
            glEnd();

            thunderDuration--;

            if (thunderDuration <= 0) {
                thunderActive = false; // End thunder effect
                glColor3f(0.0f, 0.0f, 0.5f); // Restore sky color (example sky color)
                glBegin(GL_QUADS);
                    glVertex2f(-1.0f, 1.0f);
                    glVertex2f(1.0f, 1.0f);
                    glVertex2f(1.0f, 0.0f);
                    glVertex2f(-1.0f, 0.0f);
                glEnd();
            }
        }
    }
}



void drawFish(float x, float y) {
    glColor3f(1.f, 0.5f, 0.0f);  // Orange color for the fish
    drawEllipse(x, y, 0.05f, 0.02f, 100, 0.5f, 0.5f, 0.5f);  // Fish body
    glBegin(GL_TRIANGLES);  // Tail
    glVertex2f(x - 0.06f, y);
    glVertex2f(x - 0.08f, y + 0.02f);
    glVertex2f(x - 0.08f, y - 0.02f);
    glEnd();
}


void drawFisherman(float x, float y) {
    // Body Parameters
    float headRadius = 0.05f;
    float bodyWidth = 0.04f;
    float bodyHeight = 0.1f;
    float legWidth = 0.01f;
    float legHeight = 0.07f;
    float armWidth = 0.02f;
    float armHeight = 0.06f;

    // Draw Head
    glColor3f(1.0f, 0.8f, 0.6f);  // Skin color
    drawCircle(x, y + bodyHeight + headRadius, headRadius, 100, 1.0f, 0.8f, 0.6f);  // Head

    // Draw Facial Features

    // Draw Hat
    glColor3f(0.3f, 0.2f, 0.1f);  // Dark brown for hat
    glBegin(GL_TRIANGLES);
    glVertex2f(x - headRadius, y + bodyHeight + 2 * headRadius);
    glVertex2f(x + headRadius, y + bodyHeight + 2 * headRadius);
    glVertex2f(x, y + bodyHeight + 2.5f * headRadius);
    glEnd();

    // Draw Body (Clothing)
    glColor3f(0.0f, 0.0f, 0.8f);  // Blue shirt
    drawRect(x - bodyWidth, y, x + bodyWidth, y + bodyHeight, 0.0f, 0.0f, 0.8f);  // Torso

    // Draw Arms
    glColor3f(1.0f, 0.8f, 0.6f);  // Skin color for arms
    // Left Arm
    drawRect(x - bodyWidth - armWidth, y + 0.05f, x - bodyWidth, y + 0.05f + armHeight, 1.0f, 0.8f, 0.6f);
    // Right Arm holding fishing rod
    glColor3f(1.0f, 0.8f, 0.6f);  // Skin color
    drawRect(x + bodyWidth, y + 0.05f, x + bodyWidth + armWidth, y + 0.05f + armHeight, 1.0f, 0.8f, 0.6f);

   // Draw Fishing Rod
    glColor3f(0.4f, 0.2f, 0.0f);  // Brown color
    float rodLength = 0.1f;  // Length of the rod
    float rodXEnd = x + bodyWidth + armWidth + rodLength * cos(fishingRodAngle * M_PI / 180.0);
    float rodYEnd = y + 0.05f + armHeight + rodLength * sin(fishingRodAngle * M_PI / 180.0);

    glBegin(GL_LINES);
    glVertex2f(x + bodyWidth + armWidth, y + 0.05f + armHeight);  // Start of rod
    glVertex2f(rodXEnd, rodYEnd);  // End of rod
    glEnd();

    // Draw Fishing Line
    glColor3f(0.0f, 0.0f, 0.0f);  // Black color for the fishing line
    float lineLength = 0.2f;  // Length of the line
    float lineXEnd = rodXEnd + lineLength * cos(fishingRodAngle * M_PI / 180.0);
    float lineYEnd = rodYEnd + lineLength * sin(fishingRodAngle * M_PI / 180.0);

    glBegin(GL_LINES);
    glVertex2f(rodXEnd, rodYEnd);  // Start of line (end of rod)
    glVertex2f(lineXEnd, lineYEnd);  // End of line
    glEnd();

    // Draw Fishing Hook
    glColor3f(1.0f, 0.0f, 0.0f);  // Red color for the hook
    float hookSize = 0.02f;  // Size of the hook
    float hookX = lineXEnd;  // Position of the hook
    float hookY = lineYEnd;  // Position of the hook

    // Draw a small hook shape
    glBegin(GL_LINE_STRIP);
    glVertex2f(hookX, hookY);  // Point where the hook attaches
    glVertex2f(hookX + hookSize * cos(fishingRodAngle * M_PI / 180.0),
               hookY + hookSize * sin(fishingRodAngle * M_PI / 180.0)); // Hook curve
    glVertex2f(hookX, hookY - hookSize); // Hook point
    glEnd();
    // Draw Legs
    glColor3f(0.0f, 0.0f, 0.0f);  // Black pants
    // Left Leg
    drawRect(x - legWidth - 0.005f, y - legHeight, x - legWidth + 0.005f, y, 0.0f, 0.0f, 0.0f);
    // Right Leg
    drawRect(x + legWidth - 0.005f, y - legHeight, x + legWidth + 0.005f, y, 0.0f, 0.0f, 0.0f);

    // Draw Shoes
    glColor3f(0.545f, 0.271f, 0.075f);  // Brown shoes
    // Left Shoe
    drawRect(x - legWidth - 0.01f, y - legHeight, x - legWidth + 0.01f, y - legHeight + 0.005f, 0.545f, 0.271f, 0.075f);
    // Right Shoe
    drawRect(x + legWidth - 0.01f, y - legHeight, x + legWidth + 0.01f, y - legHeight + 0.005f, 0.545f, 0.271f, 0.075f);

    // Optional: Add details like belt
    glColor3f(0.545f, 0.271f, 0.075f);  // Brown belt
    drawRect(x - bodyWidth, y + 0.05f, x + bodyWidth, y + 0.06f, 0.545f, 0.271f, 0.075f);  // Belt

    // Optional: Add a pocket or other clothing details
    glColor3f(0.8f, 0.8f, 0.8f);  // Light gray for pocket
    drawRect(x - 0.015f, y + 0.02f, x - 0.005f, y + 0.04f, 0.8f, 0.8f, 0.8f);  // Pocket

       // Bucket beside the fisherman
    glColor3f(0.5f, 0.5f, 0.5f);  // Gray color for the bucket

    drawRect(x + 0.1f, y - 0.17f, x + 0.14f, y - 0.1f, 0.3f, 0.3f, 0.3f);  // Bucket handle

}



void drawBucket(float x, float y) {
    glColor3f(0.5f, 0.35f, 0.05f);  // Brown bucket
    drawRect(x - 0.05f, y, x + 0.05f, y + 0.1f, 0.5f, 0.35f, 0.05f);  // Bucket
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    drawSky();  // Draw the sky





    // River
    drawRect(-1.0f, -0.5f, 1.0f, 0.0f, 0.0f, 0.3f, 0.8f);  // River background
    drawRiver();  // Draw the more realistic river
 // Draw mountains behind the land area
    drawMountains();

    if(isRain==false){
            if(iscloud==false){
     if (isDay) {
        drawSun(); // Call your existing draw sun function
        // Land area (replacing the hill)

    // Trees beside the houses (realistic version)
    drawTree(-0.55f, 0.0f);  // Tree 1 (beside first house)
    drawTree(0.25f, 0.0f);   // Tree 2 (beside second house)
    drawTree(0.7f, 0.06f);   // Tree 3 (extra tree)
    drawLandArea();
         drawFisherman(-0.2f ,-0.6f);  // Adjust the position as needed

    }
    else if(!isDay)
     {
        drawMoon(); // Call the moon drawing function

    // Trees beside the houses (realistic version)
    drawnightTree(-0.55f, 0.0f);  // Tree 1 (beside first house)
    drawnightTree(0.25f, 0.0f);   // Tree 2 (beside second house)
    drawnightTree(0.7f, 0.06f);   // Tree 3 (extra tree)
        drawnightLandArea();
    }
    }
    else{

      drawcloudSky();
      drawThunder();
       drawMountains();


    }
    }

    else{

             drawcloudSky();
       // River
    drawRect(-1.0f, -0.5f, 1.0f, 0.0f, 0.0f, 0.3f, 0.8f);  // River background
    drawRiver();  // Draw the more realistic river
 // Draw mountains behind the land area
   drawThunder(); // Draw thunder effect
    drawMountains();
        drawRain();
        drawThunder(); // Draw thunder effect
        //drawFisherman(-0.2f ,-0.6f);  // Adjust the position as needed


    }




    // Clouds
    drawCloud(cloudX, 0.8f);  // Draw moving cloud
    drawCloud(cloudX2, 0.6f);
    drawCloud(cloudX3, 0.7f);



    // Houses and other elements as before
    drawHouse(-0.3f, 0.0f);  // First house on the left
    drawHouse(0.4f, 0.1f);   // Second house on the right

    // Trees beside the houses (realistic version)
    drawTree(-0.55f, 0.0f);  // Tree 1 (beside first house)
    drawTree(0.25f, 0.0f);   // Tree 2 (beside second house)
    drawTree(0.7f, 0.06f);   // Tree 3 (extra tree)

    // Draw fish if not caught
    if (!fishCaught) {
        drawFish(fishX, fishY);

        drawFish(fishX +0.4f, -0.3f);

        drawFish(fishX +0.6f, -0.2f);

    }



    // Realistic Boat (centered in the river)
    drawBoat();

       // Houses and Trees below the river (lowered)
    drawHouse(-0.8f, -0.7f);  // First house on the left
    drawHouse(0.4f, -0.7f);   // Second house on the right

     drawTree(-0.55f, -0.8f);  // Tree 1 (beside first house)
    drawTree(0.7f, -0.85f);   // Tree 2 (beside second house)

        // Draw birds flying in the sky
    drawBird(birdX, 0.85f);  // First bird
    drawBird(birdX + 0.2f, 0.9f);  // Second bird flying behind
    drawBird(birdX + 0.4f, 0.87f);  // Third bird flying higher


     // Draw the fisherman beside the river





    glFlush();
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(800, 600);
    glutCreateWindow("Scenery with Realistic Houses");
    glClearColor(0.529f, 0.808f, 0.0f,0.8f);  // Light blue sky
    gluOrtho2D(-1.0, 1.0, -1.0, 1.0);
    srand(time(0));
    glutDisplayFunc(display);
    glutKeyboardFunc(keyboard);
    glutIdleFunc(idle);  // Register the idle function
    glutMainLoop();
    return 0;
}
