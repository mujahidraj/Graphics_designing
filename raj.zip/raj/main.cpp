#include <GL/glut.h>
#include<math.h>
void drawRect(float x1, float y1, float x2, float y2, float r, float g, float b) {
    glColor3f(r, g, b);
    glBegin(GL_POLYGON);
    glVertex2f(x1, y1);
    glVertex2f(x2, y1);
    glVertex2f(x2, y2);
    glVertex2f(x1, y2);
    glEnd();
}

void drawTriangle(float x1, float y1, float x2, float y2, float x3, float y3, float r, float g, float b) {
    glColor3f(r, g, b);
    glBegin(GL_TRIANGLES);
    glVertex2f(x1, y1);
    glVertex2f(x2, y2);
    glVertex2f(x3, y3);
    glEnd();
}

void drawCircle(float cx, float cy, float radius, int num_segments, float r, float g, float b) {
    glColor3f(r, g, b);
    glBegin(GL_TRIANGLE_FAN);
    for (int i = 0; i < num_segments; i++) {
        float theta = 2.0f * 3.1415926f * float(i) / float(num_segments);
        float x = radius * cos(theta);
        float y = radius * sin(theta);
        glVertex2f(x + cx, y + cy);
    }
    glEnd();
}

void drawBoat() {
    // Hull of the boat (trapezoid)
    glColor3f(0.6f, 0.3f, 0.0f);  // Brown
    glBegin(GL_POLYGON);
    glVertex2f(0.2f, -0.3f);
    glVertex2f(0.7f, -0.3f);
    glVertex2f(0.6f, -0.4f);
    glVertex2f(0.3f, -0.4f);
    glEnd();

    // Upper part of the boat (rectangle)
    drawRect(0.25f, -0.2f, 0.65f, -0.3f, 1.0f, 0.5f, 0.0f);  // Yellow

    // Mast
    drawRect(0.45f, -0.2f, 0.48f, 0.1f, 0.5f, 0.35f, 0.05f);  // Dark brown

    // Sail
    drawTriangle(0.48f, 0.1f, 0.48f, -0.05f, 0.65f, 0.1f, 0.9f, 0.9f, 0.9f);  // White sail
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    // Sky
    drawRect(-1.0f, 0.0f, 1.0f, 1.0f, 0.529f, 0.808f, 0.98f);  // Light blue sky

    // Water
    drawRect(-1.0f, -1.0f, 1.0f, 0.0f, 0.0f, 0.5f, 1.0f);  // Blue water

    // Sun
    drawCircle(0.7f, 0.7f, 0.1f, 100, 1.0f, 1.0f, 0.0f);  // Yellow sun

    // Clouds
    drawCircle(-0.7f, 0.8f, 0.1f, 100, 0.8f, 0.8f, 0.8f);  // Left cloud
    drawCircle(-0.6f, 0.85f, 0.08f, 100, 0.8f, 0.8f, 0.8f); // Left cloud
    drawCircle(0.6f, 0.8f, 0.1f, 100, 0.8f, 0.8f, 0.8f);   // Right cloud
    drawCircle(0.7f, 0.85f, 0.08f, 100, 0.8f, 0.8f, 0.8f);  // Right cloud

    // Hill
    drawTriangle(-1.0f, 0.0f, 0.0f, 0.4f, 1.0f, 0.0f, 0.0f, 0.8f, 0.0f);  // Green hill

    // House
    drawRect(-0.2f, 0.0f, 0.0f, 0.2f, 1.0f, 0.8f, 0.0f);  // Yellow house body
    drawTriangle(-0.25f, 0.2f, -0.1f, 0.35f, 0.05f, 0.2f, 0.8f, 0.0f, 0.0f);  // Red roof

    // Tree
    drawRect(-0.6f, 0.0f, -0.55f, 0.2f, 0.8f, 0.5f, 0.2f);  // Brown trunk
    drawCircle(-0.575f, 0.3f, 0.1f, 100, 0.0f, 0.8f, 0.0f);  // Green leaves

    // Realistic Boat
    drawBoat();

    glFlush();
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(800, 600);
    glutCreateWindow("Scenery with Realistic Boat");
    glClearColor(0.529f, 0.808f, 0.98f, 1.0f);  // Light blue sky
    gluOrtho2D(-1.0, 1.0, -1.0, 1.0);
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}
