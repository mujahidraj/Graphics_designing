#include <GL/glut.h>
#include <math.h>

float boatX = 0.0f;  // Boat's horizontal position
bool moveBoat = false;  // Flag to start moving the boat

float sunX = -1.0f;  // Initial position of the sun
float sunY = 0.7f;
float sunDirection = 0.0f;  // 0.0 for stationary, 1.0 for moving right

float cloudX = -0.7f;  // Initial horizontal position of the cloud
float cloudX2 = -0.3f;
float cloudX3 = 0.7f;
float cloudSpeed = 0.0f;  // Speed of cloud movement



void drawRect(float x1, float y1, float x2, float y2, float r, float g, float b) {
    glColor3f(r, g, b);
    glBegin(GL_POLYGON);
    glVertex2f(x1, y1);
    glVertex2f(x2, y1);
    glVertex2f(x2, y2);
    glVertex2f(x1, y2);
    glEnd();
}

void drawTriangle(float x1, float y1, float x2, float y2, float x3, float y3, float r, float g, float b) {
    glColor3f(r, g, b);
    glBegin(GL_TRIANGLES);
    glVertex2f(x1, y1);
    glVertex2f(x2, y2);
    glVertex2f(x3, y3);
    glEnd();
}

void drawCircle(float cx, float cy, float radius, int num_segments, float r, float g, float b) {
    glColor3f(r, g, b);
    glBegin(GL_TRIANGLE_FAN);
    for (int i = 0; i < num_segments; i++) {
        float theta = 2.0f * 3.1415926f * float(i) / float(num_segments);
        float x = radius * cos(theta);
        float y = radius * sin(theta);
        glVertex2f(x + cx, y + cy);
    }
    glEnd();
}

void drawEllipse(float cx, float cy, float rx, float ry, int num_segments, float r, float g, float b) {
    glColor3f(r, g, b);
    glBegin(GL_TRIANGLE_FAN);
    for (int i = 0; i < num_segments; i++) {
        float theta = 2.0f * 3.1415926f * float(i) / float(num_segments);
        float x = rx * cosf(theta);
        float y = ry * sinf(theta);
        glVertex2f(x + cx, y + cy);
    }
    glEnd();
}

void drawTree(float x, float y) {
    // Trunk
    drawRect(x - 0.025f, y, x + 0.025f, y + 0.2f, 0.545f, 0.271f, 0.075f);  // Brown trunk

    // Leaves (using ellipses and circles to create a more realistic look)
    drawEllipse(x, y + 0.25f, 0.15f, 0.1f, 100, 0.0f, 0.6f, 0.0f);  // Bottom layer of leaves
    drawEllipse(x + 0.05f, y + 0.35f, 0.1f, 0.08f, 100, 0.0f, 0.8f, 0.0f);  // Middle layer of leaves
    drawEllipse(x - 0.05f, y + 0.35f, 0.1f, 0.08f, 100, 0.0f, 0.7f, 0.0f);  // Middle layer of leaves
    drawCircle(x, y + 0.4f, 0.1f, 100, 0.0f, 0.9f, 0.0f);  // Top layer of leaves
}


  // Initial position of the boat

void keyboard(unsigned char key, int x, int y) {
    switch (key) {
        case 'r':
            // Start moving the sun
            sunDirection = 1.0f;
            moveBoat = true;
            cloudSpeed =0.000015f;

            break;
        case 27: // ESC key to exit
            exit(0);
            break;
    }
    glutPostRedisplay();
}


void idle() {
    if (sunDirection == 1.0f) {
        sunX += 0.00001f; // Move the sun to the right
        sunY += 0.000001f; // Move the sun upwards

        if (sunX > 1.0f) {  // Stop at the right side
            sunX = -1.3f;
            sunY = 0.9f;
            sunDirection = -2.0f;
        }
    }

    if (moveBoat) {
        boatX += 0.0001f;  // Change this value to adjust the speed of the boat
        if (boatX > 1.5f) boatX = -1.2f;  // Reset position if it goes off-screen
    }

    // Move the cloud
    cloudX += cloudSpeed;
    if (cloudX > 1.0f) cloudX = -1.0f;  // Reset cloud position if it goes off-screen

    cloudX2 += cloudSpeed;
    if (cloudX2 > 1.0f) cloudX2 = -1.0f;  // Reset cloud position if it goes off-screen

     cloudX3 += cloudSpeed;
    if (cloudX3 > 1.0f) cloudX3 = -1.0f;  // Reset cloud position if it goes off-screen



    glutPostRedisplay();
}


void drawCloud(float x, float y) {
    drawCircle(x, y, 0.1f, 100, 1.0f, 1.0f, 1.0f);  // Main part of the cloud
    drawCircle(x + 0.1f, y - 0.02f, 0.08f, 100, 1.0f, 1.0f, 1.0f);  // Left part of the cloud
    drawCircle(x + 0.1f, y + 0.1f, 0.08f, 100, 1.0f, 1.0f, 1.0f);  // Right part of the cloud
}



void drawBoat() {
    // Hull of the boat (trapezoid)
    glColor3f(0.6f, 0.3f, 0.0f);  // Brown
    glBegin(GL_POLYGON);
    glVertex2f(boatX - 0.15f, -0.3f);
    glVertex2f(boatX + 0.15f, -0.3f);
    glVertex2f(boatX + 0.1f, -0.4f);
    glVertex2f(boatX - 0.1f, -0.4f);
    glEnd();

    // Upper part of the boat (rectangle)
    drawRect(boatX - 0.1f, -0.2f, boatX + 0.1f, -0.3f, 1.0f, 0.5f, 0.0f);  // Yellow

    // Mast
    drawRect(boatX - 0.02f, -0.2f, boatX + 0.02f, 0.1f, 0.5f, 0.35f, 0.05f);  // Dark brown

    // Sail
    drawTriangle(boatX + 0.02f, 0.1f, boatX + 0.02f, -0.05f, boatX + 0.1f, 0.1f, 0.9f, 0.9f, 0.9f);  // White sail
}



void drawMountain(float x, float y, float width, float height, float r, float g, float b) {
    glColor3f(r, g, b);
    glBegin(GL_TRIANGLES);
    glVertex2f(x - width / 2, y);  // Left vertex
    glVertex2f(x + width / 2, y);  // Right vertex
    glVertex2f(x, y + height);     // Top vertex
    glEnd();
}

void drawMountains() {
    // Draw layered mountains behind the land area
    drawMountain(-0.8f, 0.1f, 0.6f, 0.4f, 0.6f, 0.3f, 0.2f);  // Mountain 1 (left)
    drawMountain(-0.4f, 0.1f, 0.7f, 0.5f, 0.5f, 0.35f, 0.25f);  // Mountain 2 (left center)
    drawMountain(0.0f, 0.1f, 0.6f, 0.4f, 0.6f, 0.3f, 0.2f);    // Mountain 3 (center)
    drawMountain(0.4f, 0.1f, 0.7f, 0.5f, 0.5f, 0.35f, 0.25f);   // Mountain 4 (right center)
    drawMountain(0.8f, 0.1f, 0.6f, 0.4f, 0.6f, 0.3f, 0.2f);    // Mountain 5 (right)
}

void drawLandArea() {
    // Land area (a simple flat green field)
    drawRect(-1.0f, -0.1f, 1.0f, 0.1f, 0.0f, 0.8f, 0.0f);  // Flat green area
}


void drawHouse(float x, float y) {
    // House body
    drawRect(x, y, x + 0.2f, y + 0.2f, 1.0f, 0.8f, 0.0f);  // Yellow body

    // Roof
    drawTriangle(x - 0.05f, y + 0.2f, x + 0.1f, y + 0.35f, x + 0.25f, y + 0.2f, 0.8f, 0.0f, 0.0f);  // Red roof

    // Door
    drawRect(x + 0.08f, y, x + 0.12f, y + 0.1f, 0.5f, 0.3f, 0.0f);  // Brown door

    // Windows
    drawRect(x + 0.02f, y + 0.12f, x + 0.06f, y + 0.16f, 0.0f, 0.6f, 1.0f);  // Left window
    drawRect(x + 0.14f, y + 0.12f, x + 0.18f, y + 0.16f, 0.0f, 0.6f, 1.0f);  // Right window
}

void drawRiver() {
    // River base with gradient
    glBegin(GL_POLYGON);
    glColor3f(0.0f, 0.3f, 0.8f);  // Darker blue for the deeper parts
    glVertex2f(-1.0f, -0.5f);
    glVertex2f(1.0f, -0.5f);
    glColor3f(0.0f, 0.5f, 1.0f);  // Lighter blue for the shallower parts
    glVertex2f(1.0f, -0.5f);
    glVertex2f(-1.0f, -0.5f);
    glEnd();

    // Adding waves (simplified version)
    glColor3f(1.0f, 1.0f, 1.0f);  // White for waves
    glBegin(GL_LINES);
    for (float y = -0.5f; y < -0.1f; y += 0.05f) {
        for (float x = -1.0f; x < 1.0f; x += 0.1f) {
            glVertex2f(x, y);
            glVertex2f(x + 0.05f, y + 0.03f);
        }
    }
    glEnd();
}

void drawRain() {
    glColor3f(1.0f, 1.0f, 1.0f);  // Light grey for rain
    glBegin(GL_LINES);
    for (int i = 0; i < 100; i++) {
        float x = (float)rand() / RAND_MAX * 2.0f - 1.0f;  // Random x between -1 and 1
        float y = (float)rand() / RAND_MAX * 2.0f - 1.0f;  // Random y between -1 and 1
        glVertex2f(x, y);
        glVertex2f(x, y - 0.1f);  // Short rain drops
    }
    glEnd();
}




void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    // Sky
    drawRect(-1.0f, 0.0f, 1.0f, 1.0f, 0.529f, 0.808f, 0.98f);  // Light blue sky

    // Draw mountains behind the land area
    drawMountains();

    // River
    drawRect(-1.0f, -0.5f, 1.0f, 0.0f, 0.0f, 0.3f, 0.8f);  // River background
    drawRiver();  // Draw the more realistic river

    // Sun
    drawCircle(sunX, sunY, 0.1f, 100, 1.0f, 1.0f, 0.0f);  // Yellow sun

    // Clouds
    drawCloud(cloudX, 0.8f);  // Draw moving cloud
    drawCloud(cloudX2, 0.6f);
    drawCloud(cloudX3, 0.7f);

    // Land area (replacing the hill)
    drawLandArea();

    // Houses and other elements as before
    drawHouse(-0.3f, 0.0f);  // First house on the left
    drawHouse(0.4f, 0.1f);   // Second house on the right

    // Trees beside the houses (realistic version)
    drawTree(-0.55f, 0.0f);  // Tree 1 (beside first house)
    drawTree(0.25f, 0.0f);   // Tree 2 (beside second house)
    drawTree(0.7f, 0.06f);   // Tree 3 (extra tree)

    // Realistic Boat (centered in the river)
    drawBoat();

       // Houses and Trees below the river (lowered)
    drawHouse(-0.8f, -0.7f);  // First house on the left
    drawHouse(0.4f, -0.7f);   // Second house on the right

     drawTree(-0.55f, -0.8f);  // Tree 1 (beside first house)
    drawTree(0.7f, -0.85f);   // Tree 2 (beside second house)


    glFlush();
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(800, 600);
    glutCreateWindow("Scenery with Realistic Houses");
    glClearColor(0.529f, 0.808f, 0.0f,0.8f);  // Light blue sky
    gluOrtho2D(-1.0, 1.0, -1.0, 1.0);
    glutDisplayFunc(display);
    glutKeyboardFunc(keyboard);
    glutIdleFunc(idle);  // Register the idle function
    glutMainLoop();
    return 0;
}
