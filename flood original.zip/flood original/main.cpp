#include <GL/glut.h>
#include <math.h>
#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

// Additional global variable for water movement
float riverFlowOffset = 0.0f;
float riverSpeed = 0.00009f;  // Speed of the river flow

float boatX = 0.0f;  // Boat's horizontal position
bool moveBoat = false;  // Flag to start moving the boat\


float sunX = -1.0f;  // Initial position of the sun
float sunY = 0.7f;
float sunDirection = 0.0f;  // 0.0 for stationary, 1.0 for moving right

float cloudX = -0.7f;  // Initial horizontal position of the cloud
float cloudX2 = -0.3f;
float cloudX3 = 0.7f;
float cloudSpeed = 0.0f;  // Speed of cloud movement

bool isRaining = false;  // New flag for controlling rain



void drawRect(float x1, float y1, float x2, float y2, float r, float g, float b) {
    glColor3f(r, g, b);
    glBegin(GL_POLYGON);
    glVertex2f(x1, y1);
    glVertex2f(x2, y1);
    glVertex2f(x2, y2);
    glVertex2f(x1, y2);
    glEnd();
}

void drawTriangle(float x1, float y1, float x2, float y2, float x3, float y3, float r, float g, float b) {
    glColor3f(r, g, b);
    glBegin(GL_TRIANGLES);
    glVertex2f(x1, y1);
    glVertex2f(x2, y2);
    glVertex2f(x3, y3);
    glEnd();
}

void drawCircle(float cx, float cy, float radius, int num_segments, float r, float g, float b) {
    glColor3f(r, g, b);
    glBegin(GL_TRIANGLE_FAN);
    for (int i = 0; i < num_segments; i++) {
        float theta = 2.0f * 3.1415926f * float(i) / float(num_segments);
        float x = radius * cos(theta);
        float y = radius * sin(theta);
        glVertex2f(x + cx, y + cy);
    }
    glEnd();
}

void drawEllipse(float cx, float cy, float rx, float ry, int num_segments, float r, float g, float b) {
    glColor3f(r, g, b);
    glBegin(GL_TRIANGLE_FAN);
    for (int i = 0; i < num_segments; i++) {
        float theta = 2.0f * 3.1415926f * float(i) / float(num_segments);
        float x = rx * cosf(theta);
        float y = ry * sinf(theta);
        glVertex2f(x + cx, y + cy);
    }
    glEnd();
}

void keyboard(unsigned char key, int x, int y) {
    switch (key) {
        case 'r':
            moveBoat = true;  // Start moving the boat
            break;
        case 's':
            moveBoat = false;  // Stop moving the boat
            break;
        case 'd':  // Start raining when 'd' is pressed
            isRaining = true;
            break;
        case 'f':  // Stop raining when 'f' is pressed
            isRaining = false;
            break;
        case 27:  // ESC key to exit
            exit(0);
            break;
    }
    glutPostRedisplay();
}

void idle() {

     riverFlowOffset += riverSpeed;
    if (riverFlowOffset > 0.1f) {
        riverFlowOffset -= 0.1f;  // Reset wave position smoothly
    }

  // Move the boat only if the flag is set
    if (moveBoat) {
        boatX += 0.0001f;  // Change this value to adjust the speed of the boat
        if (boatX > 1.5f) boatX = -1.2f;  // Reset position if it goes off-screen
    }

    // Automatically move the sun
    sunX += 0.0001f; // Move the sun to the right
   // sunY += 0.0000009f; // Move the sun upwards
    cloudSpeed = 0.00009f;  // Ensure cloud speed is set

    if (sunX > 1.0f) {  // Stop at the right side
        sunX = -1.3f;
        sunY = 0.9f;
    }

    // Move the clouds automatically
    cloudX += cloudSpeed;
    if (cloudX > 1.0f) cloudX = -1.0f;  // Reset cloud position if it goes off-screen

    cloudX2 += cloudSpeed;
    if (cloudX2 > 1.0f) cloudX2 = -1.0f;  // Reset cloud position if it goes off-screen

    cloudX3 += cloudSpeed;
    if (cloudX3 > 1.0f) cloudX3 = -1.0f;  // Reset cloud position if it goes off-screen


     glutPostRedisplay();

}


// Function to draw a realistic tree
void drawTree(float x, float y) {
    // Trunk
    drawRect(x - 0.025f, y, x + 0.025f, y + 0.2f, 0.545f, 0.271f, 0.075f);  // Brown trunk

    // Leaves (using ellipses and circles to create a more realistic look)
    drawEllipse(x, y + 0.25f, 0.15f, 0.1f, 100, 0.0f, 0.6f, 0.0f);  // Bottom layer of leaves
    drawEllipse(x + 0.05f, y + 0.35f, 0.1f, 0.08f, 100, 0.0f, 0.8f, 0.0f);  // Middle layer of leaves
    drawEllipse(x - 0.05f, y + 0.35f, 0.1f, 0.08f, 100, 0.0f, 0.7f, 0.0f);  // Middle layer of leaves
    drawCircle(x, y + 0.4f, 0.1f, 100, 0.0f, 0.9f, 0.0f);  // Top layer of leaves
}

void drawMountain(float x, float y, float width, float height, float r, float g, float b) {
    glColor3f(r, g, b);
    glBegin(GL_TRIANGLES);
    glVertex2f(x - width / 2, y);  // Left vertex
    glVertex2f(x + width / 2, y);  // Right vertex
    glVertex2f(x, y + height);     // Top vertex
    glEnd();
}

void drawMountains() {
    // Draw layered mountains behind the land area
    drawMountain(-0.8f, -0.1f, 0.6f, 0.4f, 0.6f, 0.3f, 0.2f);  // Mountain 1 (left)
    drawMountain(-0.4f, -0.1f, 0.7f, 0.5f, 0.5f, 0.35f, 0.25f);  // Mountain 2 (left center)
    drawMountain(0.0f, -0.1f, 0.6f, 0.4f, 0.6f, 0.3f, 0.2f);    // Mountain 3 (center)
    drawMountain(0.4f, -0.1f, 0.7f, 0.5f, 0.5f, 0.35f, 0.25f);   // Mountain 4 (right center)
    drawMountain(0.8f, -0.1f, 0.6f, 0.4f, 0.6f, 0.3f, 0.2f);    // Mountain 5 (right)
}

// Function to draw the sky
void drawSky() {
    drawRect(-1.0f, 0.0f, 1.0f, 1.0f, 0.5f, 0.5f, 0.5f);  // Light blue sky
}

// Function to draw the field
void drawField() {
    drawRect(-1.0f, -0.5f, 1.0f, -0.1f, 0.0f, 0.8f, 0.0f);  // Green field
}

// Function to draw the sun
void drawSun() {
    drawCircle(-0.7f, 0.7f, 0.1f, 20, 1.0f, 1.0f, 0.0f);  // Yellow sun
}

// Function to draw a more realistic house
void drawHouse(float x, float y) {
    // Draw house body with varied texture
    drawRect(x - 0.12f, y, x + 0.12f, y + 0.1f, 0.9f, 0.7f, 0.4f);  // Light brown body

    // Draw roof with different shape
    drawTriangle(x - 0.15f, y + 0.1f, x + 0.15f, y + 0.1f, x, y + 0.25f, 0.5f, 0.0f, 0.0f);  // Dark red roof

    // Draw windows
    drawRect(x - 0.1f, y + 0.03f, x - 0.05f, y + 0.07f, 0.0f, 0.0f, 1.0f);  // Left window (blue)
    drawRect(x + 0.05f, y + 0.03f, x + 0.1f, y + 0.07f, 0.0f, 0.0f, 1.0f);  // Right window (blue)

    // Draw door
    drawRect(x - 0.02f, y, x + 0.02f, y + 0.1f, 0.5f, 0.3f, 0.1f);  // Brown door
}

void drawRiver() {
    // River base with gradient
    glBegin(GL_POLYGON);
    glColor3f(0.0f, 0.3f, 0.8f);  // Darker blue for the deeper parts
    glVertex2f(-1.0f, -1.0f);
    glVertex2f(1.0f, -1.0f);
    glColor3f(0.0f, 0.5f, 1.0f);  // Lighter blue for the shallower parts
    glVertex2f(1.0f, -0.5f);
    glVertex2f(-1.0f, -0.5f);
    glEnd();

    // Moving water effect
    glColor3f(1.0f, 1.0f, 1.0f);  // White for waves
    glBegin(GL_LINES);
    for (float y = -1.0f; y < -0.5f; y += 0.05f) {
        for (float x = -1.0f; x < 1.0f; x += 0.1f) {
            // Shift the waves to the right to simulate movement
            float waveOffset = (x + riverFlowOffset);
            glVertex2f(waveOffset, y);
            glVertex2f(waveOffset + 0.05f, y + 0.03f);
        }
    }
    glEnd();
}

void drawBoat() {
    // Hull of the boat (trapezoid)
    glColor3f(0.6f, 0.3f, 0.0f);  // Brown
    glBegin(GL_POLYGON);
    glVertex2f(boatX - 0.15f, -0.7f);
    glVertex2f(boatX + 0.15f, -0.7f);
    glVertex2f(boatX + 0.1f, -0.8f);
    glVertex2f(boatX - 0.1f, -0.8f);
    glEnd();

    // Upper part of the boat (rectangle)
    drawRect(boatX - 0.1f, -0.6f, boatX + 0.1f, -0.7f, 1.0f, 0.5f, 0.0f);  // Yellow

    // Mast
    drawRect(boatX - 0.001f, -0.6f, boatX + 0.02f, -0.3f, 0.5f, 0.35f, 0.05f);  // Dark brown

    // Sail
    drawTriangle(boatX + 0.02f, -0.3f, boatX + 0.02f, -0.5f, boatX + 0.2f, -0.4f, 0.9f, 0.9f, 0.9f);  // White sail
}

void drawRain() {
    glColor3f(1.0f, 1.0f, 1.0f);  // Light grey for rain
    glBegin(GL_LINES);
    for (int i = 0; i < 100; i++) {
        float x = (float)rand() / RAND_MAX * 2.0f - 1.0f;
        float y = (float)rand() / RAND_MAX * 2.0f - 1.0f;
        glVertex2f(x, y);
        glVertex2f(x, y - 0.1f);  // Short rain drops
    }
    glEnd();
}


void drawCloud(float x, float y) {
    drawCircle(x, y, 0.1f, 100, 0.7f, 0.7f, 0.7f);  // Main part of the cloud
    drawCircle(x + 0.1f, y - 0.02f, 0.08f, 100, 0.7f, 0.7f, 0.7f);  // Left part of the cloud
    drawCircle(x + 0.1f, y + 0.1f, 0.08f, 100, 0.7f, 0.7f, 0.7f);  // Right part of the cloud
}


// Display function
void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    drawSky();

    // Sun
    drawCircle(sunX + 0.25f, sunY+0.1f, 0.1f, 100, 1.0f, 1.0f, 0.0f);  // Yellow sun

    // Clouds
    drawCloud(cloudX, 0.8f);  // Draw moving cloud
    drawCloud(cloudX2, 0.6f);
    drawCloud(cloudX3, 0.7f);

    drawField();
    drawMountains();  // Draw mountains first to ensure they are behind the land


       // Draw multiple houses with different positions
    drawHouse(-0.3f, -0.3f);
    drawHouse(0.0f, -0.43f);
    drawHouse(0.3f, -0.1f);
    // Draw multiple realistic trees
    drawTree(-0.8f, -0.3f);
    drawTree(-0.5f, -0.4f);
    drawTree(0.2f, -0.3f);
    drawTree(0.6f, -0.2f);

    drawRiver();

    drawBoat();

    drawRain();

    glFlush();
}


// Initialization function
void init() {
    glClearColor(0.5f, 0.5f, 0.5f, 1.0f);  // Set the clear color (sky color)
    glColor3f(0.0f, 0.0f, 0.0f);  // Set the drawing color
    glMatrixMode(GL_PROJECTION);
    gluOrtho2D(-1.0, 1.0, -1.0, 1.0);  // Set the coordinate system
}

// Main function
int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(800, 600);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("Countryside Scene with Realistic Houses");
    init();
     glutKeyboardFunc(keyboard);
    glutIdleFunc(idle);  // Register the idle function
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}
