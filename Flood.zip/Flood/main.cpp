#include <GL/glut.h>
#include <math.h>

void drawRect(float x1, float y1, float x2, float y2, float r, float g, float b) {
    glColor3f(r, g, b);
    glBegin(GL_POLYGON);
    glVertex2f(x1, y1);
    glVertex2f(x2, y1);
    glVertex2f(x2, y2);
    glVertex2f(x1, y2);
    glEnd();
}

void drawTriangle(float x1, float y1, float x2, float y2, float x3, float y3, float r, float g, float b) {
    glColor3f(r, g, b);
    glBegin(GL_TRIANGLES);
    glVertex2f(x1, y1);
    glVertex2f(x2, y2);
    glVertex2f(x3, y3);
    glEnd();
}

void drawCircle(float cx, float cy, float radius, int num_segments, float r, float g, float b) {
    glColor3f(r, g, b);
    glBegin(GL_TRIANGLE_FAN);
    for (int i = 0; i < num_segments; i++) {
        float theta = 2.0f * 3.1415926f * float(i) / float(num_segments);
        float x = radius * cos(theta);
        float y = radius * sin(theta);
        glVertex2f(x + cx, y + cy);
    }
    glEnd();
}

void drawBoat() {
    // Hull of the boat (trapezoid)
    glColor3f(0.6f, 0.3f, 0.0f);  // Brown
    glBegin(GL_POLYGON);
    glVertex2f(-0.15f, -0.3f);
    glVertex2f(0.15f, -0.3f);
    glVertex2f(0.1f, -0.4f);
    glVertex2f(-0.1f, -0.4f);
    glEnd();

    // Upper part of the boat (rectangle)
    drawRect(-0.1f, -0.2f, 0.1f, -0.3f, 1.0f, 0.5f, 0.0f);  // Yellow

    // Mast
    drawRect(-0.02f, -0.2f, 0.02f, 0.1f, 0.5f, 0.35f, 0.05f);  // Dark brown

    // Sail
    drawTriangle(0.02f, 0.1f, 0.02f, -0.05f, 0.1f, 0.1f, 0.9f, 0.9f, 0.9f);  // White sail
}

void drawHill() {
    // Base hill with gradient
    glBegin(GL_POLYGON);
    glColor3f(0.0f, 0.8f, 0.0f);  // Darker green
    glVertex2f(-1.0f, 0.0f);
    glVertex2f(0.0f, 0.4f);
    glVertex2f(1.0f, 0.0f);
    glColor3f(0.2f, 1.0f, 0.2f);  // Lighter green at the base
    glVertex2f(1.0f, -0.1f);
    glVertex2f(-1.0f, -0.1f);
    glEnd();

    // Adding some grass on the hill
    drawTriangle(-0.6f, 0.1f, -0.55f, 0.15f, -0.5f, 0.1f, 0.0f, 0.5f, 0.0f);  // Small grass
    drawTriangle(-0.3f, 0.2f, -0.25f, 0.25f, -0.2f, 0.2f, 0.0f, 0.6f, 0.0f);  // Small grass
    drawTriangle(0.4f, 0.15f, 0.45f, 0.2f, 0.5f, 0.15f, 0.0f, 0.5f, 0.0f);  // Small grass

    // Adding bushes on the hill
    drawCircle(-0.7f, 0.2f, 0.05f, 100, 0.0f, 0.6f, 0.0f);  // Bush
    drawCircle(0.6f, 0.2f, 0.07f, 100, 0.0f, 0.6f, 0.0f);  // Bush
    drawCircle(0.3f, 0.3f, 0.06f, 100, 0.0f, 0.6f, 0.0f);  // Bush
}

void drawHouse(float x, float y) {
    // House body
    drawRect(x, y, x + 0.2f, y + 0.2f, 1.0f, 0.8f, 0.0f);  // Yellow body

    // Roof
    drawTriangle(x - 0.05f, y + 0.2f, x + 0.1f, y + 0.35f, x + 0.25f, y + 0.2f, 0.8f, 0.0f, 0.0f);  // Red roof

    // Door
    drawRect(x + 0.08f, y, x + 0.12f, y + 0.1f, 0.5f, 0.3f, 0.0f);  // Brown door

    // Windows
    drawRect(x + 0.02f, y + 0.12f, x + 0.06f, y + 0.16f, 0.0f, 0.6f, 1.0f);  // Left window
    drawRect(x + 0.14f, y + 0.12f, x + 0.18f, y + 0.16f, 0.0f, 0.6f, 1.0f);  // Right window
}

void drawRiver() {
    // River base with gradient
    glBegin(GL_POLYGON);
    glColor3f(0.0f, 0.3f, 0.8f);  // Darker blue for the deeper parts
    glVertex2f(-1.0f, -0.5f);
    glVertex2f(1.0f, -0.5f);
    glColor3f(0.0f, 0.5f, 1.0f);  // Lighter blue for the shallower parts
    glVertex2f(1.0f, -0.5f);
    glVertex2f(-1.0f, -0.5f);
    glEnd();

    // Adding waves (simplified version)
    glColor3f(1.0f, 1.0f, 1.0f);  // White for waves
    glBegin(GL_LINES);
    for (float y = -0.5f; y < -0.1f; y += 0.05f) {
        for (float x = -1.0f; x < 1.0f; x += 0.1f) {
            glVertex2f(x, y);
            glVertex2f(x + 0.05f, y + 0.03f);
        }
    }
    glEnd();
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);




    // Sky
    drawRect(-1.0f, 0.0f, 1.0f, 1.0f, 0.529f, 0.808f, 0.98f);  // Light blue sky

    drawRect(-1.0f, -0.5f, 1.0f, 0.0f, 0.0f, 0.3f, 0.8f);

    // River
    drawRiver();  // Draw the more realistic river



    // Sun
    drawCircle(0.7f, 0.7f, 0.1f, 100, 1.0f, 1.0f, 0.0f);  // Yellow sun

    // Clouds
    drawCircle(-0.7f, 0.8f, 0.1f, 100, 1.0f, 1.0f, 1.0f);  // Left cloud
    drawCircle(-0.6f, 0.85f, 0.08f, 100, 1.0f, 1.0f, 1.0f); // Left cloud
    drawCircle(0.6f, 0.8f, 0.1f, 100, 1.0f, 1.0f, 1.0f);   // Right cloud
    drawCircle(0.7f, 0.85f, 0.08f, 100,  1.0f, 1.0f, 1.0f);  // Right cloud

    // Realistic Hill with Gradient and Grass
    drawHill();

    // Houses
    drawHouse(-0.3f, 0.0f);
    drawHouse(0.4f, 0.1f);

    // Trees beside the houses
    // Tree 1 (beside first house)
    drawRect(-0.55f, 0.0f, -0.50f, 0.2f, 0.8f, 0.5f, 0.2f);  // Brown trunk
    drawCircle(-0.525f, 0.25f, 0.1f, 100, 0.0f, 0.6f, 0.0f);  // Green leaves

    // Tree 2 (beside second house)
    drawRect(0.25f, 0.0f, 0.30f, 0.2f, 0.8f, 0.5f, 0.2f);  // Brown trunk
    drawCircle(0.275f, 0.25f, 0.1f, 100, 0.0f, 0.6f, 0.0f);  // Green leaves

    // Tree 3 (beside second house)
    drawRect(0.55f, 0.0f, 0.60f, 0.2f, 0.8f, 0.5f, 0.2f);  // Brown trunk
    drawCircle(0.575f, 0.25f, 0.1f, 100, 0.0f, 0.6f, 0.0f);  // Green leaves





    // Realistic Boat (centered in the river)
    drawBoat();

    glFlush();
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(800, 600);
    glutCreateWindow("Scenery with Realistic Houses");
    glClearColor(0.529f, 0.808f, 0.0f,0.8f);  // Light blue sky
    gluOrtho2D(-1.0, 1.0, -1.0, 1.0);
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}
